import { useState } from "react";

function App() {
  const [name, setName] = useState("");
  const [location, setLocation] = useState("");

  const addEvent = async () => {
    if (!name || !location) {
      alert("Please fill all fields");
      return;
    }

    await fetch("http://localhost:5000/api/events", {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
      },
      body: JSON.stringify({ name, location }),
    });

    alert("Event Added ✅");
    setName("");
    setLocation("");
  };

  return (
    <div style={{ padding: "40px", textAlign: "center" }}>
      <h1>Mini Event Platform</h1>

      <input
        placeholder="Event Name"
        value={name}
        onChange={(e) => setName(e.target.value)}
      />
      <br /><br />

      <input
        placeholder="Location"
        value={location}
        onChange={(e) => setLocation(e.target.value)}
      />
      <br /><br />

      <button onClick={addEvent}>Add Event</button>
    </div>
  );
}

export default App;